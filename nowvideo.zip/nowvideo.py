import re

########################################################################################################################################

import os                   
import urllib2
import cookielib
import socket

DATA_PATH = './'

HEADERS = {'User-Agent': 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; es-ES; rv:1.9.2.12) Gecko/20101026 Firefox/3.6.12'}

class CookiePolice(cookielib.DefaultCookiePolicy):
    def set_ok(self, cookie, request):
        return cookielib.DefaultCookiePolicy.set_ok(self, cookie, request)

    def return_ok(self, cookie, request):
        return cookielib.DefaultCookiePolicy.return_ok(self, cookie, request)

    def domain_return_ok(self, domain, request):
        return cookielib.DefaultCookiePolicy.domain_return_ok(self, domain, request)
        
    def path_return_ok(self,path, request):
        return cookielib.DefaultCookiePolicy.path_return_ok(self, path, request)
        
def gzip_decode(data):
    import StringIO
    compressedstream = StringIO.StringIO(data)
    import gzip
    gzipper = gzip.GzipFile(fileobj=compressedstream)
    data = gzipper.read()
    gzipper.close()
    
    return data

def downloadpage(url, post=None, headers=HEADERS, follow_redirects=True, timeout=socket.getdefaulttimeout(), header_to_get=None):
    f_cookie = os.path.join(DATA_PATH, 'cookies.dat')
    
    cj = None
    urlopen = urllib2.urlopen
    Request = urllib2.Request
    
    cj = cookielib.MozillaCookieJar()
    cj.set_policy(CookiePolice()) # use DefaultCookiePolicy ?
    
    if cj is not None:
        if os.path.isfile(f_cookie):
            try:
                cj.load(f_cookie, ignore_discard=True)
            except:
                os.remove(f_cookie)
                
        if not follow_redirects:
            opener = urllib2.build_opener(urllib2.HTTPHandler(debuglevel=1), urllib2.HTTPCookieProcessor(cj), NoRedirectHandler())
        else:
            opener = urllib2.build_opener(urllib2.HTTPHandler(debuglevel=1), urllib2.HTTPCookieProcessor(cj))
        
        urllib2.install_opener(opener)
        
    """
    urllib2.Request(url[, data][, headers][, origin_req_host][, unverifiable])
    
    data may be a string specifying additional data to send to the server, or None if no such data is needed. Currently HTTP requests are the only ones 
    that use data; the HTTP request will be a POST instead of a GET when the data parameter is provided. data should be a buffer in the standard 
    application/x-www-form-urlencoded format. The urllib.urlencode() function takes a mapping or sequence of 2-tuples and returns a string in this format.
    """
    
    if post is None:
        # make a GET request
        req = Request(url, headers=headers)
    else:
        # make a POST request
        req = Request(url, data, headers)
        
    try:
        if timeout is None:
            handle=urlopen(req)
        else:        
            deftimeout = socket.getdefaulttimeout()
            socket.setdefaulttimeout(timeout)
            handle=urlopen(req)            
            socket.setdefaulttimeout(deftimeout)
        
        cj.save(f_cookie, ignore_discard=True)

        data=handle.read()
        
        if handle.info().get('Content-Encoding') == 'gzip':
            data = gzip_decode(data)
            
    except urllib2.HTTPError, e:
        data = e.read()
        return None, data

    info = handle.info()
    for header in info:
        if header_to_get is not None:
            if header==header_to_get:
                data=info[header]

    handle.close()
    return info, data
    
########################################################################################################################################

REGEXP_NOWVIDEO = ['nowvideo.../video/([a-z0-9]+)',
                   'player3k.info/nowvideo/\?id\=([a-z0-9]+)',
                   'nowvideo.../embed.php\?v\=([a-z0-9]+)',
                   'nowvideo.../embed.php\?.+?v\=([a-z0-9]+)']
    
def norm_url(url):
    res = None
    for rexp in REGEXP_NOWVIDEO:
        m = re.search(rexp, url, re.DOTALL)
        if m: 
            res = "http://embed.nowvideo.sx/embed.php?v=%s" % m.group(1)
            break
    
    return res

def find_single_match(data, regex, index=0):
    try:
        matches = re.findall(regex ,data ,flags=re.DOTALL )
        return matches[index]
    except:
        return ""
    
def get_video_url(url):
    video_urls = []
    header, data = downloadpage(url)
    print header
    
    video_id = find_single_match(data, 'flashvars\.file\s*=\s*"([^"]+)')
    flashvar_filekey = find_single_match(data, 'flashvars\.file[_]*key\s*=\s*([^;]+)')
    filekey = find_single_match(data, 'var\s+%s\s*=\s*"([^"]+)' % flashvar_filekey)
    filekey = filekey.replace(".", "%2E").replace("-", "%2D")
    
    print video_id
    print flashvar_filekey
    print filekey
    
    # get stream url from api
    url = 'http://www.nowvideo.sx/api/player.api.php?key=%s&file=%s' % (filekey, video_id)
    header, data = downloadpage(url)
    print header
    
    data = find_single_match(data, 'url=([^&]+)')
    print data
    
    """
    res = scrapertools.get_header_from_response(url, header_to_get="content-type")
    if res == "text/html":
        data = urllib.quote_plus(data).replace(".", "%2E")
        url = 'http://www.nowvideo.sx/api/player.api.php?cid3=undefined&numOfErrors=1&user=undefined&errorUrl=%s&pass=undefined&errorCode=404&cid=1&cid2=undefined&file=%s&key=%s' % (
            data, video_id, filekey)
        data = scrapertools.cache_page(url)
        try:
            data = scrapertools.find_single_match(data, 'url=([^&]+)')
        except:
            url = 'http://www.nowvideo.sx/api/player.api.php?key=%s&file=%s' % (filekey, video_id)
            data = scrapertools.cache_page(url)
            data = scrapertools.find_single_match(data, 'url=([^&]+)')

    media_url = data

    video_urls.append([scrapertools.get_filename_from_url(media_url)[-4:] + " [nowvideo]", media_url])
    """
    return video_urls
    
nowvideo_url = 'http://www.nowvideo.li/video/1943300ff6887'
print nowvideo_url
print norm_url(nowvideo_url)
print "-"*50
get_video_url(norm_url(nowvideo_url))